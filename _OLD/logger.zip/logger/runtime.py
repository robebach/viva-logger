from __future__ import annotations

import datetime as dt
import math
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal, Optional

from .hardware import LabjackDriver
from .models import (
    ControlState,
    DeviceMeta,
    DeviceTemperatureConfig,
    I2CConfig,
    LabjackConfig,
    LogRecord,
    LoggerConfig,
    PWMConfig,
    RelayConfig,
    SensorReading,
    T9602Config,
    ThermistorConfig,
)


# ----------------------------
# Psychrometric helpers
# ----------------------------

def saturation_pressure_pa(temp_k: float) -> float:
    """
    Saturation pressure in Pa.

    Constants are the same style as your existing ASHRAE-based pws() function.
    """

    c8 = -5.8002206e3
    c9 = 1.3914993
    c10 = -4.8640239e-2
    c11 = 4.1764768e-5
    c12 = -1.4452093e-8
    c13 = 6.5459673

    return math.exp(
        c8 / temp_k
        + c9
        + c10 * temp_k
        + c11 * temp_k**2
        + c12 * temp_k**3
        + c13 * math.log(temp_k)
    )


def dewpoint_c_from_temp_rh(temp_c: float, rh_fraction: float) -> float:
    rh_fraction = max(0.000001, min(1.0, rh_fraction))

    temp_k = temp_c + 273.15
    pws_pa = saturation_pressure_pa(temp_k)
    pw_kpa = pws_pa * rh_fraction * 0.001

    a = math.log(pw_kpa)

    c14 = 6.54
    c15 = 14.526
    c16 = 0.7389
    c17 = 0.09486
    c18 = 0.4569

    return (
        c14
        + c15 * a
        + c16 * a**2
        + c17 * a**3
        + c18 * pw_kpa**0.1984
    )


def c_to_f(temp_c: float) -> float:
    return temp_c * 9.0 / 5.0 + 32.0


# ----------------------------
# Sensor runtime classes
# ----------------------------

@dataclass
class SensorRuntime(ABC):
    config: DeviceTemperatureConfig | T9602Config | ThermistorConfig

    @property
    def name(self) -> str:
        return self.config.name

    @property
    def sensor_type(self) -> str:
        return self.config.sensor_type

    @abstractmethod
    def read(self, driver: LabjackDriver) -> SensorReading:
        raise NotImplementedError


@dataclass
class DeviceTemperatureRuntime(SensorRuntime):
    config: DeviceTemperatureConfig

    def read(self, driver: LabjackDriver) -> SensorReading:
        temp_k = driver.read_device_temperature_k()
        temp_c = temp_k - 273.15
        temp_f = c_to_f(temp_c)

        return SensorReading(
            name=self.name,
            sensor_type=self.sensor_type,
            values={
                "temp_k": temp_k,
                "temp_c": temp_c,
                "temp_f": temp_f,
            },
            status=0,
        )


@dataclass
class T9602Runtime(SensorRuntime):
    config: T9602Config

    def read(self, driver: LabjackDriver) -> SensorReading:
        i2c: I2CConfig = self.config.i2c

        raw = driver.read_i2c(
            sda=i2c.sda_dio,
            scl=i2c.scl_dio,
            addr=i2c.address,
            rx_len=i2c.rx_len,
        )

        if len(raw) < 4:
            raise ValueError(
                f"T9602 expected 4 bytes but received {len(raw)} bytes."
            )

        status = (raw[0] >> 6) & 0x03

        rh_raw = ((raw[0] & 0x3F) << 8) | raw[1]
        rh_fraction = rh_raw / 16384.0

        temp_raw = (raw[2] << 6) | (raw[3] >> 2)
        temp_c = (temp_raw / 16384.0) * 165.0 - 40.0
        temp_f = c_to_f(temp_c)

        dewpoint_c = dewpoint_c_from_temp_rh(temp_c, rh_fraction)
        dewpoint_f = c_to_f(dewpoint_c)

        return SensorReading(
            name=self.name,
            sensor_type=self.sensor_type,
            values={
                "rh": rh_fraction,
                "rh_pct": rh_fraction * 100.0,
                "temp_c": temp_c,
                "temp_f": temp_f,
                "dewpoint_c": dewpoint_c,
                "dewpoint_f": dewpoint_f,
            },
            status=status,
            raw_data=raw,
        )


@dataclass
class ThermistorRuntime(SensorRuntime):
    config: ThermistorConfig

    def read(self, driver: LabjackDriver) -> SensorReading:
        voltage = driver.read_ain(ain=self.config.ain)

        return SensorReading(
            name=self.name,
            sensor_type=self.sensor_type,
            values={
                "voltage": voltage,
                "note": "Thermistor conversion not implemented yet.",
            },
            status=0,
            raw_data=[voltage],
        )


# ----------------------------
# Control runtime classes
# ----------------------------

@dataclass
class RelayRuntime:
    config: RelayConfig
    state: Literal[0, 1] = field(init=False)

    def __post_init__(self) -> None:
        self.state = self.config.initial_state

    @property
    def name(self) -> str:
        return self.config.name

    def apply(self, driver: LabjackDriver) -> None:
        driver.set_relay(
            dio=self.config.dio,
            state=self.state,
        )

    def set_state(
        self,
        state: Literal[0, 1],
        driver: Optional[LabjackDriver] = None,
    ) -> None:
        self.state = 1 if state else 0

        if driver is not None:
            self.apply(driver)

    def toggle(self, driver: Optional[LabjackDriver] = None) -> None:
        self.set_state(
            0 if self.state else 1,
            driver=driver,
        )

    def snapshot(self) -> ControlState:
        return ControlState(
            name=self.name,
            control_type="relay",
            values={
                "dio": self.config.dio,
                "onoff": self.state,
            },
        )


@dataclass
class PWMRuntime:
    config: PWMConfig

    duty_cycle: float = field(init=False)
    enabled: bool = field(init=False)

    def __post_init__(self) -> None:
        self.duty_cycle = self.config.duty_cycle
        self.enabled = self.config.enabled

    @property
    def name(self) -> str:
        return self.config.name

    def configure_and_apply(self, driver: LabjackDriver) -> None:
        driver.configure_pwm(
            dio=self.config.dio,
            frequency_hz=self.config.frequency_hz,
            duty_cycle=self.output_duty_cycle,
            roll_value=self.config.roll_value,
        )

    @property
    def output_duty_cycle(self) -> float:
        if not self.enabled:
            return 0.0

        return max(0.0, min(1.0, self.duty_cycle))

    def apply(self, driver: LabjackDriver) -> None:
        driver.set_pwm(
            dio=self.config.dio,
            duty_cycle=self.output_duty_cycle,
        )

    def set_duty_cycle(
        self,
        duty_cycle: float,
        driver: Optional[LabjackDriver] = None,
    ) -> None:
        self.duty_cycle = max(0.0, min(1.0, duty_cycle))

        if driver is not None:
            self.apply(driver)

    def set_enabled(
        self,
        enabled: bool,
        driver: Optional[LabjackDriver] = None,
    ) -> None:
        self.enabled = enabled

        if driver is not None:
            self.apply(driver)

    def snapshot(self) -> ControlState:
        return ControlState(
            name=self.name,
            control_type="pwm",
            values={
                "dio": self.config.dio,
                "frequency_hz": self.config.frequency_hz,
                "duty_cycle": self.duty_cycle,
                "enabled": self.enabled,
                "output_duty_cycle": self.output_duty_cycle,
            },
        )


# ----------------------------
# Managers / orchestration
# ----------------------------

@dataclass
class AcquisitionManager:
    sensors: list[SensorRuntime] = field(default_factory=list)

    def collect(self, driver: LabjackDriver) -> list[SensorReading]:
        return [
            sensor.read(driver)
            for sensor in self.sensors
        ]


@dataclass
class ControlManager:
    relays: list[RelayRuntime] = field(default_factory=list)
    pwm_outputs: list[PWMRuntime] = field(default_factory=list)

    def initialize(self, driver: LabjackDriver) -> None:
        for relay in self.relays:
            relay.apply(driver)

        for pwm in self.pwm_outputs:
            pwm.configure_and_apply(driver)

    def snapshots(self) -> list[ControlState]:
        states: list[ControlState] = []

        for relay in self.relays:
            states.append(relay.snapshot())

        for pwm in self.pwm_outputs:
            states.append(pwm.snapshot())

        return states


@dataclass
class LogWriter:
    log_dir: Path
    current_path: Optional[Path] = None

    def path_for_today(self) -> Path:
        today = dt.date.today().isoformat()
        return self.log_dir / f"{today}.jsonl"

    def write(self, record: LogRecord) -> Path:
        self.log_dir.mkdir(parents=True, exist_ok=True)

        path = self.path_for_today()
        self.current_path = path

        with path.open("a", encoding="utf-8") as f:
            f.write(record.model_dump_json() + "\n")

        return path


@dataclass
class Scheduler:
    sample_interval_s: float
    next_sample_at: Optional[float] = None

    def reset(self) -> None:
        self.next_sample_at = time.monotonic()

    def due(self) -> bool:
        if self.next_sample_at is None:
            self.reset()

        assert self.next_sample_at is not None

        return time.monotonic() >= self.next_sample_at

    def mark_sample_complete(self) -> None:
        now = time.monotonic()

        if self.next_sample_at is None:
            self.next_sample_at = now + self.sample_interval_s
            return

        while self.next_sample_at <= now:
            self.next_sample_at += self.sample_interval_s


@dataclass
class SystemRuntime:
    config: LoggerConfig
    driver: LabjackDriver

    acquisition: AcquisitionManager
    controls: ControlManager
    log_writer: LogWriter
    scheduler: Scheduler

    def connect(self) -> "SystemRuntime":
        self.driver.connect()
        return self

    def initialize(self) -> "SystemRuntime":
        self.controls.initialize(self.driver)
        self.scheduler.reset()
        return self

    def collect_record(self) -> LogRecord:
        errors: list[str] = []
        sensor_readings: list[SensorReading] = []

        for sensor in self.acquisition.sensors:
            try:
                sensor_readings.append(sensor.read(self.driver))
            except Exception as exc:
                errors.append(f"{sensor.name}: {type(exc).__name__}: {exc}")

        device = DeviceMeta(
            device_type=self.config.device.device_type,
            serial_number=self.driver.serial_number,
            connected=self.driver.connected,
        )

        return LogRecord(
            timestamp=dt.datetime.now(dt.timezone.utc),
            device=device,
            sensors=sensor_readings,
            controls=self.controls.snapshots(),
            errors=errors,
        )

    def write_record(self, record: LogRecord) -> Path:
        return self.log_writer.write(record)

    def run_once(self, *, write: bool = True) -> tuple[LogRecord, Optional[Path]]:
        record = self.collect_record()

        path = None
        if write:
            path = self.write_record(record)

        self.scheduler.mark_sample_complete()

        return record, path

    def close(self) -> None:
        self.driver.close()


# ----------------------------
# Builders
# ----------------------------

def build_sensor_runtime(
    config: DeviceTemperatureConfig | T9602Config | ThermistorConfig,
) -> SensorRuntime:
    if isinstance(config, DeviceTemperatureConfig):
        return DeviceTemperatureRuntime(config=config)

    if isinstance(config, T9602Config):
        return T9602Runtime(config=config)

    if isinstance(config, ThermistorConfig):
        return ThermistorRuntime(config=config)

    raise TypeError(f"Unsupported sensor config: {config!r}")


def build_runtime(
    config: LoggerConfig,
    *,
    driver: Optional[LabjackDriver] = None,
) -> SystemRuntime:
    driver = driver or LabjackDriver(config.device)

    sensors = [
        build_sensor_runtime(sensor_config)
        for sensor_config in config.sensors
    ]

    relays = [
        RelayRuntime(config=relay_config)
        for relay_config in config.relays
    ]

    pwm_outputs = [
        PWMRuntime(config=pwm_config)
        for pwm_config in config.pwm_outputs
    ]

    return SystemRuntime(
        config=config,
        driver=driver,
        acquisition=AcquisitionManager(sensors=sensors),
        controls=ControlManager(
            relays=relays,
            pwm_outputs=pwm_outputs,
        ),
        log_writer=LogWriter(log_dir=config.log_dir),
        scheduler=Scheduler(sample_interval_s=config.sample_interval_s),
    )