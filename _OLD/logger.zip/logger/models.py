from __future__ import annotations

import datetime as dt
from pathlib import Path
from typing import Annotated, Any, Literal, Optional, Union

from pydantic import BaseModel, ConfigDict, Field


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


# ----------------------------
# Device config
# ----------------------------

class LabjackConfig(StrictModel):
    device_type: Literal["T4", "T7", "ANY"] = "ANY"
    serial_number: str = "ANY"
    connection_type: str = "ANY"


class I2CConfig(StrictModel):
    sda_dio: int = Field(..., ge=0)
    scl_dio: int = Field(..., ge=0)
    address: int = Field(..., ge=0x00, le=0x7F)
    rx_len: int = Field(4, gt=0)
    speed: int = Field(65536, gt=0)


# ----------------------------
# Control config
# ----------------------------

class RelayConfig(StrictModel):
    name: str
    dio: int = Field(..., ge=0)
    initial_state: Literal[0, 1] = 0

    cycle_times: list[dt.time] = Field(default_factory=list)
    cycle_duration_s: float = Field(30.0, ge=0.0)


class PWMConfig(StrictModel):
    name: str
    dio: int = Field(..., ge=0)

    frequency_hz: float = Field(1000.0, gt=0.0)
    duty_cycle: float = Field(0.0, ge=0.0, le=1.0)
    enabled: bool = True

    # For LabJack T-series DIO_EF PWM clocking.
    # If None, hardware layer can calculate from frequency_hz.
    roll_value: Optional[int] = Field(None, ge=2)


# ----------------------------
# Sensor config
# ----------------------------

class DeviceTemperatureConfig(StrictModel):
    sensor_type: Literal["device_temperature"] = "device_temperature"
    name: str = "labjack"


class T9602Config(StrictModel):
    sensor_type: Literal["t9602"] = "t9602"
    name: str
    i2c: I2CConfig


class ThermistorConfig(StrictModel):
    sensor_type: Literal["thermistor"] = "thermistor"
    name: str

    ain: int = Field(..., ge=0)
    nominal_resistance_ohm: float = Field(10_000.0, gt=0.0)
    nominal_temperature_c: float = 25.0
    beta: Optional[float] = None
    pullup_resistance_ohm: Optional[float] = None


SensorConfig = Annotated[
    Union[
        DeviceTemperatureConfig,
        T9602Config,
        ThermistorConfig,
    ],
    Field(discriminator="sensor_type"),
]


# ----------------------------
# Top-level config
# ----------------------------

class LoggerConfig(StrictModel):
    log_dir: Path = Path("LOGS")
    sample_interval_s: float = Field(1.0, gt=0.0)

    device: LabjackConfig
    sensors: list[SensorConfig] = Field(default_factory=list)
    relays: list[RelayConfig] = Field(default_factory=list)
    pwm_outputs: list[PWMConfig] = Field(default_factory=list)


# ----------------------------
# State / reading models
# ----------------------------

class DeviceMeta(StrictModel):
    device_type: str
    serial_number: Optional[str] = None
    connected: bool = False


class SensorReading(StrictModel):
    name: str
    sensor_type: str

    values: dict[str, Any] = Field(default_factory=dict)
    status: Optional[int] = None
    raw_data: Optional[list[Any]] = None


class ControlState(StrictModel):
    name: str
    control_type: Literal["relay", "pwm"]

    values: dict[str, Any] = Field(default_factory=dict)


class LogRecord(StrictModel):
    version: Literal["0.1"] = "0.1"

    timestamp: dt.datetime
    device: DeviceMeta

    sensors: list[SensorReading] = Field(default_factory=list)
    controls: list[ControlState] = Field(default_factory=list)
    errors: list[str] = Field(default_factory=list)