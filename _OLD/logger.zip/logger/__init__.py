"""
Environmental logger package.
"""